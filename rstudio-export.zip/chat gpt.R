https://chatgpt.com/share/4893f20f-ce14-4236-8282-42e8adefabd7
https://chatgpt.com/share/ded79e38-a192-4294-811b-f78099017e49